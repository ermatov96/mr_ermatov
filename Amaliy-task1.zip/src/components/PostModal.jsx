import {Modal, ModalHeader, ModalFooter,ModalBody} from 'reactstrap'
import Select from './SelectUser'
import { useForm } from "react-hook-form";
import {useState} from 'react'

function PostModal({toggle, isOpen, save, changeUser, loading}){
  const { register, handleSubmit, watch, formState: { errors } } = useForm();

    return (
        <Modal isOpen={isOpen} toggle={toggle}>
            <ModalHeader> 
                Add post
            </ModalHeader>
            <ModalBody>
            <form id={'post-from'} onSubmit={handleSubmit(save)}>
            <input {...register("title")} placeholder={'Title'} className={'form-control my-3'} type="text" name={'title'} />
         <Select   onChange={changeUser} name={'user'}/>
            <textarea {...register("body")} className={'form-control my-3'} type="textarea" name={'body'} />
           
            </form>
            </ModalBody>
            <ModalFooter>
                <button className={'btn btn-primary'} form={'post-from'} type={'submit'} disabled={loading}>save</button>
                <button className={'btn btn-danger'} type={'button'} onClick={toggle}>cancel</button>
            </ModalFooter>
        </Modal>
    )
} export default PostModal