import {useEffect, useState} from 'react'
import { doGet } from '../service'
function Select ({onChange, name, ref}){
    const[user, setUser]=useState([])
    const[currentUser, setCurrentUser]=useState('')
    async function getUsers(){
     const users=    await   doGet('/users')
     setUser(users)
    }
    useEffect(()=>{
        getUsers()
    },[])
    function onChangeSelect(event){
        let id=event.target.value;
        let id1=id===''?'':parseInt(id)
        setCurrentUser(id1)
        if(onchange)
        onchange(id1)
    }

    return (
        <select name={name} className={'form-control'} valeu={currentUser} onChange={onChangeSelect}>
            {
                user.map(item=><option value={item.id} key={item.id}>
                    {item.name}
                </option>)
            }
        </select>
    )
}
export default Select