import { Route, Switch, Link } from 'react-router-dom';
import './App.css';
import Posts from './Pages/Posts';
import Users from './Pages/Users';
import Todos from './Pages/Todos';
import OnePost from './Pages/OnePost';
function App() {
  return (
    <div className="container">
      <h1>Json placeholder</h1>
      <Link to={'/todos'}>
        <button className={'btn btn-dark float-left m-1'}>Todos</button>
      </Link>
      <Link to={'/users'}>
        <button className={'btn btn-dark float-left m-1'}>Users</button>
      </Link>
      <Link to={'/posts'}>
        <button className={'btn btn-dark float-left m-1'}>Posts</button>
      </Link>
      <br />
      <hr />
      <br />
      <Switch>
      <Route path={'/posts/:id'} component={OnePost} />
      <Route path={'/posts'} component={Posts} />
      <Route path={'/todos'} component={Todos} />
      <Route path={'/users'} component={Users} />
      </Switch>
    </div>
  );
}

export default App;
