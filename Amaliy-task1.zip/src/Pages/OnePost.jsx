import {useEffect, useState} from 'react'
import { doGet } from '../service'
function OnePost({history, match, location}){
    const [data, setData]=useState('')
    const [user, setUser]=useState('')
useEffect(()=>{
 let id=match.params.id
    getOnePost(id)
},[])
 async function getOnePost(id){

 const onePost= await   doGet('/posts/'+id)
 setData(onePost)
 const postUser= await doGet('/users/'+onePost.userId)
 setUser(postUser)
}

return (
    <div>
        <h1>One Post</h1>
        <div className="row">
            <div className="col-md-3">
                <div className="card">
                    <div className="card-header">
                    {user.name}
                    </div>
                    <div className="card-body">
                    {user.phone}
                    </div>
                </div>
            </div>
            <div className="col-md-9">
                <div className="card">
                    <div className="card-header">
                        {data.title}
                    </div>
                    <div className="card-body">
                    {data.body}
                    </div>
                </div>
            </div>
        </div>
    </div>
)
}
export default OnePost