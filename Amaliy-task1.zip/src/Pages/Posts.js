import { useEffect, useState } from 'react'
import '../App.css'
import { doGet, doPost } from '../service'
import Select from '../components/SelectUser'
import PostModal from '../components/PostModal'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Posts({ history }) {


  function filter(userId) {
    return data.filter(item => (item.userId === parseInt(userId)) || userId === '')

  }


  const [loading, setLoading] = useState(false)
  const [data, setData] = useState([])
  const [post, setPost] = useState([])
  const [modalVisible, setModalVisible] = useState(false)
  const [user, setUser] = useState(false)
  async function getP() {
    const res = await doGet('/posts')
    setPost([...res])
    setData([...res])
  }
  async function savePost(data){
    const res= await doPost('/posts', data)
    setLoading(true)
    setModalVisible(false)
    toast("Wow so easy!");
    // alert('New post added')
    setData(prev=>{
      prev.unshift(res)
      return [...prev]
    })
    setPost(prev=>{
      prev.unshift(res)
      return [...prev]
     
    })

  }
  useEffect(() => {
    getP()
  }, [])
  function openOnePost(id) {
    history.push('./posts/' + id)
  }

 
  function onChangeUser(userId){
    const res = filter(userId)
    setPost(res)
  }
function toggleModal(){
  setModalVisible(prev=>!prev)
}
function onSubmit(data){
  setLoading(true)
  data.user=user
 savePost(data)
console.log(data)
}
function changeUser(id){
  setUser(id)
}
  return (
    <div className={'posts-page'}>
      <h1 className={'text-center'}>Posts</h1>
      <button className={'btn btn-success'} onClick={toggleModal}>Add</button>
      <br />
      <div className={'row'}>
        <div className={'col-md-3'}>
         <Select onChange={onChangeUser}/>
        </div>
      </div>
      <div className="row">
        {
          post.map((item, index) => {
            return <div className={'col-md-3 my-4'}>
              <div className="card post-card" onClick={() => openOnePost(item.id)}>
                <div key={index} className={'card-header bg-dark text-white'}>
                  {item.title}
                </div>
                <div className={'card-body'}>
                  {item.body}
                </div>
              </div>


            </div>
          })
        }</div>
        <PostModal loading={loading} changeUser={changeUser} isOpen={modalVisible} toggle={toggleModal} save={onSubmit}/>
        <ToastContainer />
    </div>
  )
}
export default Posts