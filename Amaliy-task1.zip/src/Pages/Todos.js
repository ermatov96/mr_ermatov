import {useEffect, useState} from 'react'
 import {doGet} from'../service'
 import Todo from '../components/Todo'
 import Select from '../components/SelectUser'
 import '../App.css'

function Todos (){
    const[todos, setTodos]=useState([])
    const[data, setData]=useState([])
    const[completed, setCompleted]= useState(false)
    const[isFiltering, setIsFiltering]= useState(false)
    const[currentUser, setCurrentUser]= useState('')
    const[page, setPage]= useState(1)
    const checkboxStyle={
        transform:'scale(2)'
    }
    
    function filter(userId, completed, page){
      return  data.filter((item,index)=>(item.userId==userId || !userId)
       && (item.completed===completed || !isFiltering)).filter((item,index)=>(index>=(page-1)*10 && index<page*10))
    }

   async function getTodos(){
    const res= await doGet('/todos')
        setData(res)
        setTodos (res.filter((item,index)=>index>=0 && index<10))
    }
    useEffect(()=>{
    getTodos()
    },[])
function onChangeUserSelect(userId){
 const res=filter(userId, completed, page)
 setTodos(res)
 setCurrentUser(userId)
}
function handleCheck(event){
    let checked=event.target.checked
    const res=filter(currentUser,checked, page)
    setCompleted(checked)
    setTodos(res)
    setIsFiltering(true)
}
function reset(){
    setTodos(data)
    setCurrentUser('')
    setCompleted(false)
    setIsFiltering(false)
}
function onNext(){
    setPage(prevState=>prevState+1)
}
function onPrev(){
   setPage(prevState=>prevState-1)

}
useEffect(()=>{
    const res= filter(currentUser,completed,page)
    setTodos(res)
},[page])
 return(
     <div>
         <h1 className={'text-center'}>Todos</h1>
         <br/>
         <div className={'row'}>
        <div className={'col-md-3'}>
         <Select onChange={onChangeUserSelect}/>
        </div>
        <div className="col-md-3">
            <label> 
                Completed
            <input type="checkbox" className="m-2" style={checkboxStyle}  onChange={handleCheck}checked={completed}/>
            </label>
        </div>
        <div className="col-md-1">
            <button className="btn btn-danger btn-block" onClick={reset}>Reset</button>
        </div>
      </div>
      <br/>
      <br/>
         {
             todos.map((item, index)=>{
                 return <Todo key={index} item={item}/>
             })
         }
 

 <div className={'row my-4'}>
     <div className="btn3">

   
     <div className={'.col-md-2'}>
            <button onClick={onPrev} className={'btn btn-dark'}> {'<<'} prev</button>
     </div>
         <div className="col-md-1">
             <h1>{page}</h1>
         </div>
     <div className={'.col-md-2'}>
     <button onClick={onNext} className={'btn btn-dark'}>next {'>>'}</button>
         
         </div>
         </div>
 </div>
     </div>
     
 )
}
export default Todos