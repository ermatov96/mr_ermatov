import {useEffect, useState} from 'react'
import { doGet } from '../service'

function Users(){
    const[data, setData]=useState([])
    async function getUsers(){
    const res=await doGet('/users')
    setData(res)
    }
    useEffect(()=>{
        getUsers()
    },[])
    return (
        <div>
<h1 className={'text-center'}>Users</h1>
<br/>
        <table className={'table'}>
        <thead>
            <tr>
                <th>N</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Username</th>
                <th>Website</th>
                <th>Address</th>
                <th>Company</th>
            </tr>
        </thead>
        <tbody>
            {
                data.map((item, index)=>{
                    return(
                    <tr key={index}>
                 <td> {index+1}</td>
                 <td>{item.name}</td>
                 <td>{item.phone}</td>
                 <td>{item.email}</td>
                 <td>{item.username}</td>
                 <td>{item.website}</td>
                 <td>{item.address.city}</td>
                 <td>{item.company.name}</td>
                    </tr>)
                })
            }
        </tbody>
        </table>
        </div>
    )
}
export default Users