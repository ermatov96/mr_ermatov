const students = [
  { stid: 1, stname: 'Quincy', adge: 18, ielts: 6, isDismis:true, 'ball': 130, mark:[71, 56, 89, 66, 55]},
  { stid: 2, stname: 'Jack', adge: 28, ielts: 6.5,isDismis:true, ball: 110, mark:[81, 76, 59, 96, 55]},
  { stid: 3, stname: 'Sara', adge: 38, ielts: 5.5, isDismis:true, ball: 80, mark:[61, 86, 89, 56, 65]},
  { stid: 4, stname: 'Alex', adge: 20, ielts: 8, isDismis:true, ball: 170, mark:[88, 66, 95, 66, 55]},
  { stid: 5, stname: 'Rob', adge: 22, ielts: 8, isDismis:false, ball: 10, mark:[75, 56, 89, 66, 55]},
  { stid: 6, stname: 'Ban', adge: 40, ielts: 8,isDismis:true, ball: 20, mark:[71, 56, 80, 61, 55]},
  { stid: 7, stname: 'Bob', adge: 25, ielts: 8,isDismis:false, ball: 47, mark:[71, 65, 95, 66, 58]},
  { stid: 8, stname: 'Emma', adge: 23, ielts: 4,isDismis:true, ball: 70, mark:[61, 56, 89, 96, 55]},
  { stid: 9, stname: 'Zoro', adge: 38, ielts: 6, isDismis:true, ball: 90, mark:[65, 76, 79, 66, 57]},
  { stid: 10, stname: 'Puzzle', adge: 19, ielts: 9, isDismis:true, ball: 130, mark:[71, 56, 89, 66, 66]},
  { stid: 11, stname: 'Toshmurod', adge: 17, ielts: 8, isDismis:false, ball: 120, mark:[72, 56, 79, 66, 90]},
  { stid: 12, stname: 'Boltaboy', adge: 28, ielts: 7.5, isDismis:true, ball: 150, mark:[74, 56, 79, 66, 58]},
  { stid: 13, stname: 'Forex', adge: 39, ielts: 5, isDismis:true, ball: 177, mark:[61, 55, 89, 66, 91]},
  { stid: 14, stname: 'Zomby', adge: 16, ielts: 6,isDismis:true, ball: 140, mark:[59, 66, 85, 66, 63]},
  { stid: 15, stname: 'Farah', adge: 15, ielts: 8.5, isDismis:true, ball: 5, mark:[68, 86, 90, 100, 85]},
  { stid: 16, stname: 'Emre', adge: 60, ielts: 9, isDismis:false, ball: 57, mark:[65, 77, 89, 66, 88]},
];
//   var Maxxx;
  let MaxMark;
  var mapping=students.map(function(key){
   return key.mark.reduce(function(sum,marks){
    return sum+marks;
  })
  })

  // console.log(mapping)
MaxMark=Math.max.apply( null,mapping)
console.log(MaxMark)
//   // Min MAx
//   var array=students.map(function(key){
//     return key.ielts;
//   })
//  Maxxx= Math.max.apply( null,array);
//   console.log(Maxxx);

// dismissed Students
// filterings=students.filter((d)=>{
//   return d.isDismis==false;

// })
// console.log(filterings)

//   // find student
//   let bigCities = students.filter( (e)=>{
// if(e.ielts==Maxxx)
//     return e.ielts;
      
//     });
//     console.log(bigCities);
