const students = [
  { stid: 1, stname: 'Quincy', adge: 18, ielts: 6, isDismis:true, 'ball': 130, mark:[71, 56, 89, 66, 55]},
  { stid: 2, stname: 'Jack', adge: 28, ielts: 6.5,isDismis:true, ball: 110, mark:[81, 76, 59, 96, 55]},
  { stid: 3, stname: 'Sara', adge: 38, ielts: 5.5, isDismis:true, ball: 80, mark:[61, 86, 89, 56, 65]},
  { stid: 4, stname: 'Alex', adge: 20, ielts: 8, isDismis:true, ball: 170, mark:[88, 66, 95, 66, 55]},
  { stid: 5, stname: 'Rob', adge: 22, ielts: 8, isDismis:false, ball: 10, mark:[75, 56, 89, 66, 55]},
  { stid: 6, stname: 'Ban', adge: 40, ielts: 8,isDismis:true, ball: 20, mark:[71, 56, 80, 61, 55]},
  { stid: 7, stname: 'Bob', adge: 25, ielts: 8,isDismis:false, ball: 47, mark:[71, 65, 95, 66, 58]},
  { stid: 8, stname: 'Emma', adge: 23, ielts: 4,isDismis:true, ball: 70, mark:[61, 56, 89, 96, 55]},
  { stid: 9, stname: 'Zoro', adge: 38, ielts: 6, isDismis:true, ball: 90, mark:[65, 76, 79, 66, 57]},
  { stid: 10, stname: 'Puzzle', adge: 19, ielts: 9, isDismis:true, ball: 130, mark:[71, 56, 89, 66, 66]},
  { stid: 11, stname: 'Toshmurod', adge: 17, ielts: 8, isDismis:false, ball: 120, mark:[72, 56, 79, 66, 90]},
  { stid: 12, stname: 'Boltaboy', adge: 28, ielts: 7.5, isDismis:true, ball: 150, mark:[74, 56, 79, 66, 58]},
  { stid: 13, stname: 'Forex', adge: 39, ielts: 5, isDismis:true, ball: 177, mark:[61, 55, 89, 66, 91]},
  { stid: 14, stname: 'Zomby', adge: 16, ielts: 6,isDismis:true, ball: 140, mark:[59, 66, 85, 66, 63]},
  { stid: 15, stname: 'Farah', adge: 15, ielts: 8.5, isDismis:true, ball: 5, mark:[68, 86, 90, 100, 85]},
  { stid: 16, stname: 'Emre', adge: 60, ielts: 9, isDismis:false, ball: 57, mark:[65, 77, 89, 66, 88]},
];
  let MaxMark;
  let mapping;
  let filterings=[]
  var filTered=[];
  let SmartSt=[];
  let stidd;
  let fanmee;
  let age;
  let ieltss;
  let mark;

  function takeValue(eventt){
 eventt.preventDefault()
     stidd=document.getElementById("requiredInput").value;
     fnamee=document.getElementById("fname").value;
    age=document.getElementById("age").value;
    ieltss=document.getElementById("ielts").value;
    mark=document.getElementById("ball").value;
   
    
//  document.write("my name:" ,fname)
filTered = students.filter( (e)=>{

  
  return e.ielts>ieltss

   
 });

  document.querySelector(".list").innerHTML= filTered.map(item=>{
    return '<li style = " margig-right:10px">'+ ' Name: ' +item.stname+ ' IELTS: ' + item.ielts +'</li>'
  })

  }
// const chek= document.querySelector(".checkIt").ariaChecked
function myFunction(){
  const checkBox=document.getElementById("checkIt")
  document.getElementById("requiredInput").toggleAttribute("required")
  document.getElementById("fname").toggleAttribute("required")
  document.getElementById("age").toggleAttribute("required")
  document.getElementById("ielts").toggleAttribute("required")
  document.getElementById("ball").toggleAttribute("required")

  var MAXX = document.getElementById("minmax");
  if (checkBox.checked == true){
    minmax.style.display = "block";
    dismis.style.display = "block";
    minmax2.style.display = "block";
  }
   else {
     minmax.style.display = "none";
     dismis.style.display = "none";
     minmax2.style.display = "none";
  }
}


var Maxxx;

function maxScore(evenn){
evenn.preventDefault()
  
  var array=students.map(function(key){
    return key.ielts;
  })
 Maxxx= Math.max.apply( null,array);
  console.log(Maxxx);
  // find student
  SmartSt = students.filter( (a)=>{

    if(a.ielts==Maxxx)
    
    return a.ielts;
      
    });

  document.querySelector(".list").innerHTML= SmartSt.map(item=>{
  return '<li style = " margig-right:10px">'+ ' Name: ' +item.stname+ ' IELTS: ' + item.ielts +'</li>'
})
  
}
function dismissing(){
  filterings=students.filter((d)=>{
    return d.isDismis==false;
  
  })

  

  document.querySelector(".list").innerHTML= filterings.map(item=>{
    return '<li style ="color:red !important margig-right:10px">'+ ' Name: ' +item.stname+ ' IELTS: ' + item.ielts +'</li>'})
}

function maxMark(){
  
   mapping=students.map(function(key){
   return key.mark.reduce(function(sum,marks){
    return sum+marks;
  })
  })
 
  // console.log(mapping)
MaxMark=Math.max.apply(null,mapping)

document.querySelector(".list").innerHTML= students.map(item=>{
  let comparing= item.mark.reduce(function(sum,acc){

    return sum+acc;
  })
    if(MaxMark==comparing){
 
     return '<li style ="color:red !important margig-right:10px">'+ ' Name: ' +item.stname+ ' StudeentMark:  ' + item.mark +'</li>'}}
     )
    
}

document.getElementById("minmax2").addEventListener('click', maxMark)
document.getElementById("dismis").addEventListener('click', dismissing)
document.getElementById("minmax").addEventListener('click', maxScore)



  document.getElementById("checkIt").addEventListener('click', myFunction)
  document.getElementById("submitt").addEventListener('submit', takeValue)



  
// const wrapper=document.querySelector('.wrapper')
// form =wrapper.querySelectorAll('.form')
// submitInput=form[0].querySelector('input[type="submit"]');


// function getDatForm(e){
// e.perventDefault();
// var formData=new FormData(form[0]);
// }
// function filtiring(){
//   alert(formData.get('ielts')+ '  ', formData.get('age')+ ' ', formData.get('fname') )
// }
// document.addEventListener('DOMContentLoaded', function(){
//   submitInput.addEventListener('click', getDatForm, true);
// }, true)