import axios from "axios"
import {useEffect, useState} from 'react'
function Axios (){
    const [data, setData]= useState([])
    useEffect(()=>{
        let one='https://jsonplaceholder.typicode.com/todos';
        let two='https://jsonplaceholder.typicode.com/users';
        let three='https://jsonplaceholder.typicode.com/comments'
        const requistOne=axios.get(one);
        const requistTwo=axios.get(two);
        const requistThree=axios.get(three);
        axios.all([requistOne, requistTwo, requistThree]).then(axios.spread((...responses)=>{

            const responseOne=responses[0]
            const responseTwo=responses[1]
            const responseThree=responses[2]
            // BU yerda biz qabul qilib olgan responselarimizdan foydalanishimiz mumkin
        })).catch(errors=>{
            console.log('Something Went Wrong!')
        })
    })
    return (
        <div>
{/* olgan Data larimizni bu yerda chizamiz */}
        </div>
    )
}
export default Axios