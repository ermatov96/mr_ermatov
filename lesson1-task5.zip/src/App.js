
import './App.css';
import CounterButton from './Counter';
 const user = {
  firstName: 'AA',
  lastName: 'BB',
  address: [
      {
          name: 'AA',
          count: 0
      }
  ]
}
function App (){
  
  
    return(
      <div>
        <CounterButton data={user}/>
      </div>
    )
  

}

 export default App;
