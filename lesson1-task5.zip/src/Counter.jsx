import React, {useState} from "react";
import './App.css'
function CounterButton(props){

    const [count, setCount] = useState(props.data.address[0].count);
    const counting=()=>{
        setCount(count+1)
    }
    const counting1=()=>{
        if(count>0)
        setCount(count-1)
    }
    return(
        <div className="plusm">
            <button onClick={counting1}>-</button>
            <h1>{count}</h1>
            <button onClick={counting}>+</button>
        </div>
    )
}
export default CounterButton