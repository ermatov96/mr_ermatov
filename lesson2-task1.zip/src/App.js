import Component1 from './components/1-Component';
import Component2 from './components/2-Component';
import { createContext, useReducer } from 'react';
import './App.css';
export const MyContext = createContext()
const initialState = {count: 0, count1:0, count2:0, count3:0, count4:0};
function reducer(state, action){
  switch(action.type){
    case 'increment':
      return  { ...state,count:state.count+1,count1: state.count1+1, count2: state.count2+1,count3: state.count3+1, count4: state.count4+1,};
    case 'decrement':
      return  { ...state,count:state.count-1,count1: state.count1-1, count2: state.count2-1,count3: state.count3-1, count4: state.count4-1,};

      case 'incrementa':
        return {...state,count1:state.count1 + 1}
        case 'decrementa':
        return {...state,count1:state.count1 - 1}
        case 'incrementb':
        return {...state,count2:state.count2 + 1}
        case 'decrementb':
          return {...state,count2:state.count2 - 1}
        case 'incrementc':
        return {...state,count3:state.count3 + 1}
        case 'decrementc':
          return {...state,count3:state.count3 - 1}
        case 'incrementd':
        return {...state,count4:state.count4 + 1}
        case 'decrementd':
          return {...state,count4:state.count4 - 1}
      default: 
      throw new Error()
  }


}

function App() {
  const[state, dispatch]=useReducer(reducer, initialState);
  const inc=()=>{
    dispatch({
      type:'increment'
    })
  }
  const dec=()=>{
    dispatch({
      type:'decrement'
    })
  }
  return (
    <MyContext.Provider value={{state:state, dispatch:dispatch}} >

    <div className="wrapper">
    <div className="App">
     
        <div className="btn">

        <button onClick={dec}>-</button>
        <h1>{state.count}</h1>
        <button onClick={inc}>+</button>
        </div>
        <div className="comps">
        <Component1/>
        <Component2/>
      </div>
      </div>
    

    </div>
    </MyContext.Provider>
  );
}

export default App;
