import "../App.css"
import {useContext} from'react'
import {MyContext} from'../App'
function ComponentD(){
    const value=useContext(MyContext)
    const incd=()=>{
        value.dispatch({
          type:'incrementd'
        })
      }
      const decd=()=>{
        value.dispatch({
          type:'decrementd'
        })
      }
 return(
     <div className="Wcompa">
         <h1>D Component</h1>
         <p>Count: {value.state.count4}</p>
         <div className="btn1">
             <button onClick={decd}>-</button>
             <button onClick={incd}>+</button>
         </div>

     </div>
 )
}
export default ComponentD