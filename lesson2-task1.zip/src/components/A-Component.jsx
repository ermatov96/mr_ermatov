import "../App.css"
import {useContext} from'react'
import {MyContext} from'../App'
function ComponentA(){
    const value=useContext(MyContext)
    const inca=()=>{
        value.dispatch({
          type:'incrementa'
        })
      }
      const deca=()=>{
        value.dispatch({
          type:'decrementa'
        })
      }
    
 return(
     <div className="Wcompa">
         <h1>A Component</h1>
         <p>Count:{value.state.count1}</p>
         <div className="btn1">
             <button onClick={deca}>-</button>
             <button onClick={inca}>+</button>
         </div>

     </div>
 )
}
export default ComponentA