import ComponentA from "./A-Component"
import ComponentB from "./B-Component"
import '../App.css'
function Component1 (){

    return (
        <div className="wcomp">
            <h1>1-Component</h1>

            <ComponentA/>

            <ComponentB/>
            
        </div>
    )
}
export default Component1