import "../App.css"
import {useContext} from'react'
import {MyContext} from'../App'
function ComponentB(){
    const value=useContext(MyContext)
    const incb=()=>{
        value.dispatch({
          type:'incrementb'
        })
      }
      const decb=()=>{
        value.dispatch({
          type:'decrementb'
        })
      }
 return(
     <div className="Wcompa">
         <h1>B Component</h1>
         <p>Count: {value.state.count2}</p>
         <div className="btn1">
             <button onClick={decb}>-</button>
             <button onClick={incb}>+</button>
         </div>

     </div>
 )
}
export default ComponentB