import ComponentC from "./C-Component"
import ComponentD from "./D-Component"
import '../App.css'
function Component2 (){

    return (
        <div className="wcomp">
            <h1>2-Component</h1>

            <ComponentC/>

            <ComponentD/>
            
        </div>
    )
}
export default Component2