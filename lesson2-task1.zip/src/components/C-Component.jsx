import "../App.css"
import {useContext} from'react'
import {MyContext} from'../App'
function ComponentC(){
    const value=useContext(MyContext)
    const incc=()=>{
        value.dispatch({
          type:'incrementc'
        })
      }
      const decc=()=>{
        value.dispatch({
          type:'decrementc'
        })
      }
 return(
     
     <div className="Wcompa">
         <h1>C Component</h1>
         <p>Count: {value.state.count3}</p>
         <div className="btn1">
             <button onClick={decc}>-</button>
             <button onClick={incc}>+</button>
         </div>

     </div>
 )
}
export default ComponentC