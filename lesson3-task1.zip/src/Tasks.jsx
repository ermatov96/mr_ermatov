import axios from "axios"
import { useEffect, useState } from "react"


function Task(){
    const [data, setData]=useState([])
    useEffect(()=>{
        axios({
            url:'https://jsonplaceholder.typicode.com/comments',
            method:'get'
        }).then((response)=>{
            setData(response.data)
        })
    },[])
    return (
        <div>
            <h1>Tasks page</h1>
            {
                data.map((item)=>{
                    return <li>{item.name}</li>
                })
            }
            
        </div>
    )
}
export default Task