import { useState, useEffect } from "react"
import axios from "axios"
function Post() {
    const[data, setData]=useState([])
    useEffect(()=>{
  
      axios({
        url:'https://jsonplaceholder.typicode.com/posts',
        method:"get"
      }).then((response)=>{
        setData(response.data)
      })
  
    }, [])
    return (
        <div>
            
           <h1>Posts Page</h1>
           {
               data.map((item)=>{
                return   <li>{item.title}</li>
               })
           }
        </div>
    )
}
export default Post