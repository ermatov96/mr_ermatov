import './App.css'
import {Link} from 'react-router-dom'
function Nav(){
    const navStyle={
        color:'white',
        listStyle:'none'
    }
return (
    <nav>
        <ul>
            <Link style={navStyle} to="/post">
        <li>Post</li>
        </Link>
        <Link style={navStyle} to="/task">
        <li>Tasks</li>
        </Link>
        <Link style={navStyle} to="/user">
        <li>Users</li>
        </Link>
        </ul>
    </nav>
)
}
export default Nav