import React from 'react';
import Post from './Posts';
import Task from './Tasks';
import User from './Users';
import Nav from './navbar';
import './App.css';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
function App() {
 
  return (
    <Router>
    <div className="App">
   <Nav/>
   <hr/>
   <Switch>
   <Route path="/" exact component={Home}/>
   <Route path="/post" component={Post}/>
   <Route path="/task" component={Task}/>
   <Route Route path="/user" component={User}/>
   </Switch>
    </div>
    </Router>
  );
}
const Home = () => {
  return(

  <div>
    <h1>Home Page</h1>
  </div>
  )
};

export default App;
