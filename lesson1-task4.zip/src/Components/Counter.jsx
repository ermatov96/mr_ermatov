import { useState } from 'react'
import './components.css'
function Counter() {
    const [count, setCounter] = useState(0)
    const Add = () => {
        setCounter(prev => prev + 1);
    }
    const Subs = () => {
        if (count > 0)
            setCounter(prev => prev - 1)
    }
    return (
        <div className="counter">
            <button onClick={Subs} className="btn">-</button>
            <h3>{count}</h3>
            <button onClick={Add} className="btn">+</button>
        </div>
    )
}
export default Counter