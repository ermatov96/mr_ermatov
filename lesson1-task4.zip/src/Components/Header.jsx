import './components.css'
import { useState } from 'react'
import Form from './Form'

function Header(props) {

    const [show, setShow] = useState(false)
    const showHide = () => {
        setShow(true)
    }

    return (
        <div className="wrapper">
            <button onClick={showHide}>Add</button>
            <table>
                <tr>
                    <th>#</th>
                    <th>FirstName</th>
                    <th>LastName</th>
                    <th>Phone</th>
                    <th>Active</th>
                    <th>Count</th>
                    <th>Action</th>
                </tr>
            </table>
           { show? <Form datas={props.datas1}  fan1={props.fan}/> : null}
        </div>
    )
}
export default Header