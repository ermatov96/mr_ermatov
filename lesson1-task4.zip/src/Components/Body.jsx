import Row from "./Row"
import {useState} from 'react'
function Body(props){

 return(
     <div className="wrapper1">
     <Row data2={props.data1}/>
     </div>
 )
}
export default Body