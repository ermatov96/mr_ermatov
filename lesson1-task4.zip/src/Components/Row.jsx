import { useState } from "react"
import Counter from "./Counter"
function Row(props) {
    const[remove, setRemove]=useState(props.data2)
    const Remove=(index)=>{
        var data1 = remove;
         data1.splice(index,1)
        setRemove([...data1])
        
    }
   
    return (
     

        <dive className="wrapper3">
            {
                remove.map((item,index) => {
                    return (
                        <table>
                            <tr>
                                <th>{item.id}</th>
                                <th>{item.firstName}</th>
                                <th>{item.lastName}</th>
                                <th>{item.phone}</th>
                                <th><input type="checkbox" /></th>
                                <th className="counter"> <Counter/>  </th>
                                <th className="svg"> <button onClick={()=>Remove(index)} className="img1"> <img src="https://cdn-icons-png.flaticon.com/512/747/747969.png" alt="" /> </button>  </th>
                            </tr>
                        </table>
                    )
                })
            }

        </dive>
    )
}
export default Row