import { useState } from 'react'
import './components.css'
function Form(props){
    const [myvalue, setMyvalue]=useState('')
    const [myvalue1, setMyvalue1]=useState('')
    const [myvalue2, setMyvalue2]=useState('')
    const [myvalue3, setMyvalue3]=useState('')
    const myChangeHandler = (e) => {

        ///  e.preventDefault();
          setMyvalue(e.target.value);
          
      }
      const myChange1=(e)=>{
          setMyvalue1(e.target.value)
          
      }
  
      const myChange2=(e)=>{
          setMyvalue2(e.target.value)
       
      }
      const myChange3=(e)=>{
          setMyvalue3(e.target.value)
      }
const senDing=()=>{
    const object={
        id:myvalue,
        firstName:myvalue1,
        lastName:myvalue2,
        phone:myvalue3
        
    }
    props.fan1(object)

}

    return(
        <div>
      <form action="">
           
            <table>
                <tr>

            <th><input className="id" type="id" placeholder="id" onChange={myChangeHandler} value={myvalue}  /></th>
            <th><input type="text" placeholder="firstName" onChange={myChange1} value={myvalue1} /></th>
            <th><input type="text" placeholder="lastName" onChange={myChange2}  value={myvalue2}  /></th>
            <th><input type="number" placeholder="Phone Number" onChange={myChange3} value={myvalue3}  /></th>
            <th><input type="checkbox"/></th>
                </tr>
            
            </table>
          
        </form>
        <button type="button" onClick={() => senDing()}>SEND</button>
        </div>
    )
}
export default Form