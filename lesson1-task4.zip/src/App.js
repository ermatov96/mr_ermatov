import Header from './Components/Header';
import Body from './Components/Body';
import './App.css';
import { useState } from 'react';




function App() {
  const [data, setData]=useState([
    {id:1, firstName:'Usmon', lastName:'Abdulloh', phone:'+998941396096'},
    {id:2, firstName:'Usmon', lastName:'Abdulloh', phone:'+998941396096'},
    {id:3, firstName:'Usmon', lastName:'Abdulloh', phone:'+998941396096'},
    {id:4, firstName:'Usmon', lastName:'Abdulloh', phone:'+998941396096'},
    {id:5, firstName:'Usmon', lastName:'Abdulloh', phone:'+998941396096'},
    {id:6, firstName:'Usmon', lastName:'Abdulloh', phone:'+998941396096'},
    {id:7, firstName:'Usmon', lastName:'Abdulloh', phone:'+998941396096'},
  ])
  const child=(childData)=>{
    let a=data;
    a.push(childData)
    setData([...a])
    }
  return (
    <div className="App">
    <Header datas1={data} fan={child}/>
    <Body data1={data}/>
    </div>
  );
}

export default App;
