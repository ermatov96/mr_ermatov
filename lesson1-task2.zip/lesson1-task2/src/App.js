
import './App.css';
// import Count from './Counter';
import Out from './OutPutButtons';

function App() {
  
  return (

      <div className="App"> 
       <hr/>
       <Out/>
      </div>
   
  )
}


export default App;
