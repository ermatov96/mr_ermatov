window.addEventListener('load', function1)
window.addEventListener('load', function2)
window.addEventListener('load', function3)
window.addEventListener('load', function4)



function function1(){
    const progressBar=document.getElementById("counter1")
    let counter=0;
    setInterval(()=>{
        if(counter==4000){
        clearInterval()
        }
        else {
            counter+=50;    
            progressBar.innerText=counter;
        }
    },10)
}
function function2(){
    const progressBar=document.getElementById("counter2")
    let counter=0;
    setInterval(()=>{
        if(counter==14){
        clearInterval()
        }
        else {
            counter+=1;    
            progressBar.innerText=counter;
        }
    },50)

  


}function function3(){
    

    const progressBar=document.getElementById("counter3")
    let counter=0;
    setInterval(()=>{
        if(counter==3000){
        clearInterval()
        }
        else {
            counter+=40;    
            progressBar.innerText=counter;
        }
    },10)
}function function4(){
    const progressBar=document.getElementById("counter4")
    let counter=0;
    setInterval(()=>{
        if(counter==8){
        clearInterval()
        }
        else {
            counter+=1;    
            progressBar.innerText=counter;
        }
    },100)
}