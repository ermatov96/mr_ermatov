
$(document).ready(function(){
  $(".buxoro").mouseover(function(){
    $("#line1").fadeIn();
    $("#line2").fadeIn("slow");
    $("#num").fadeIn(3000);
  });
})

$(document).ready(function(){
    $(".buxoro").mouseout(function(){
      $("#line1").fadeOut();
      $("#line2").fadeOut("slow");
      $("#num").fadeOut(100);
    });
  })
//   Namangan
  $(document).ready(function(){
    $(".nam").mouseover(function(){
      $("#nam1").fadeIn();
      $("#nam2").fadeIn("slow");
      $("#nam3").fadeIn(3000);
    });
  })
  
  $(document).ready(function(){
      $(".nam").mouseout(function(){
        $("#nam1").fadeOut();
        $("#nam2").fadeOut("slow");
        $("#nam3").fadeOut(100);
      });
    })
    // Qora Qalpoq
    $(document).ready(function(){
        $(".qora").mouseover(function(){
          $(".line12").fadeIn();
          $(".line12").fadeIn("slow");
          $(".text12").fadeIn(3000);
        });
      })
      
      $(document).ready(function(){
          $(".qora").mouseout(function(){
            $(".line12").fadeOut();
            $(".line12").fadeOut("slow");
            $(".text12").fadeOut(100);
          });
        })
        // Samarqand
    $(document).ready(function(){
        $(".sam").mouseover(function(){
          $(".line8").fadeIn();
          $(".line8").fadeIn("slow");
          $(".text8").fadeIn(3000);
        });
      })
      
      $(document).ready(function(){
          $(".sam").mouseout(function(){
            $(".line8").fadeOut();
            $(".line8").fadeOut("slow");
            $(".text8").fadeOut(100);
          });
        })

// Sirdaryo
        $(document).ready(function(){
            $(".sir").mouseover(function(){
              $(".line7").fadeIn();
              $(".line7").fadeIn("slow");
              $(".text7").fadeIn(3000);
            });
          })
          
          $(document).ready(function(){
              $(".sir").mouseout(function(){
                $(".line7").fadeOut();
                $(".line7").fadeOut("slow");
                $(".text7").fadeOut(100);
              });
            })




// Jizzah
$(document).ready(function(){
    $(".jiz").mouseover(function(){
      $(".line4").fadeIn();
      $(".line4").fadeIn("slow");
      $(".text4").fadeIn(3000);
    });
  })
  
  $(document).ready(function(){
      $(".jiz").mouseout(function(){
        $(".line4").fadeOut();
        $(".line4").fadeOut("slow");
        $(".text4").fadeOut(100);
      });
    })

    // Toshkent
    $(document).ready(function(){
        $(".tosh").mouseover(function(){
          $(".line6").fadeIn();
          $(".line6").fadeIn("slow");
          $(".text6").fadeIn(3000);
        });
      })
      
      $(document).ready(function(){
          $(".tosh").mouseout(function(){
            $(".line6").fadeOut();
            $(".line6").fadeOut("slow");
            $(".text6").fadeOut(100);
          });
        })
        // Fargona
        $(document).ready(function(){
            $(".far").mouseover(function(){
              $(".line3").fadeIn();
              $(".line3").fadeIn("slow");
              $(".text3").fadeIn(3000);
            });
          })
          
          $(document).ready(function(){
              $(".far").mouseout(function(){
                $(".line3").fadeOut();
                $(".line3").fadeOut("slow");
                $(".text3").fadeOut(100);
              });
            })
            // Andijon
            $(document).ready(function(){
                $(".and").mouseover(function(){
                  $(".line1").fadeIn();
                  $(".line1").fadeIn("slow");
                  $(".text1").fadeIn(3000);
                });
              })
              
              $(document).ready(function(){
                  $(".and").mouseout(function(){
                    $(".line1").fadeOut();
                    $(".line1").fadeOut("slow");
                    $(".text1").fadeOut(100);
                  });
                })
                // Navoi
                $(document).ready(function(){
                    $(".nav").mouseover(function(){
                      $("#nav1").fadeIn();
                      $("#nav2").fadeIn("slow");
                      $("#nav3").fadeIn(3000);
                    });
                  })
                  
                  $(document).ready(function(){
                      $(".nav").mouseout(function(){
                        $("#nav1").fadeOut();
                        $("#nav2").fadeOut("slow");
                        $("#nav3").fadeOut(100);
                      });
                    })

            // Qashqadaryo
                    $(document).ready(function(){
                        $(".qar").mouseover(function(){
                          $(".line9").fadeIn();
                          $(".line9").fadeIn("slow");
                          $(".text9").fadeIn(3000);
                        });
                      })
                      
                      $(document).ready(function(){
                          $(".qar").mouseout(function(){
                            $(".line9").fadeOut();
                            $(".line9").fadeOut("slow");
                            $(".text9").fadeOut(100);
                          });
                        })
                        // surxondaryo
                        $(document).ready(function(){
                            $(".sur").mouseover(function(){
                              $(".line10").fadeIn();
                              $(".line10").fadeIn("slow");
                              $(".text10").fadeIn(3000);
                            });
                          })
                          
                          $(document).ready(function(){
                              $(".sur").mouseout(function(){
                                $(".line10").fadeOut();
                                $(".line10").fadeOut("slow");
                                $(".text10").fadeOut(100);
                              });
                            })