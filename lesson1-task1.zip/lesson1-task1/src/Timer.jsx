import './App.css'
import { useState, useEffect } from 'react'


function Timer() {
    const def = 0;
    const [hour, setHour] = useState(def)
    const [minut, setMinut] = useState(def)
    const [second, setSecond] = useState(def)
    useEffect(() => {

        if (second === 0) {

            setMinut(prev => prev > 0 ? prev - 1 : prev = 0)
        }
    }, [second])

    useEffect(() => {
        if(minut===0){
            setHour(prev => prev > 0 ? prev - 1 : prev = 0)
            setMinut(prev=>hour>0? prev=59:0)
        }
    }, [minut])

    const Start = () => {

        setInterval((() => {
            setSecond(prev =>  minut>0 && prev===0 ? 59 :  prev > 0 ? prev - 1 : 0);

        }
        ), 1000)


    }

    return (
        <div className="wrapper">
            <div className="timer">
                <h1>{hour}</h1>
                <h1>{minut}</h1>
                <h1>{second}</h1>
            </div>
            <div className="button">
                <button onClick={() => { setHour(prev => prev + 1) }} className="btn btn-primary">Hour</button>
                <button onClick={() => { setMinut(prev => prev + 1) }} className="btn btn-warning">Minut</button>
                <button onClick={() => { setSecond(prev => prev + 1) }} className="btn btn-danger">Second</button>
            </div>
            <button onClick={Start} className="btn btn-success">Start</button>
        </div>

    )
}
export default Timer