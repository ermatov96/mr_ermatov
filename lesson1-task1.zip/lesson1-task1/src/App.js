
import './App.css';
import Timer from'./Timer'                                                                             
import Sekund from './Sekundamer';

function App() {
  
  return (

      <div className="App">
    <h3>Timer</h3>
        <Timer/>
        <hr/>
        <h3> Sekundomer </h3>
       <Sekund/>
      </div>
   
  )
}


export default App;
