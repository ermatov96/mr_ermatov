import {useState} from 'react'
import { useEffect } from 'react/cjs/react.development'

function Sekund(){
    const[time, setTime]=useState(0)
    const[isActive, setActive]=useState(false)
    const Start=()=>{
        setActive(!isActive)
    }
    const Pause=()=>{
       setActive(false)
    }
    
    useEffect(()=>{
        let id=null
        if(isActive){
        id = setInterval(()=>{
            setTime(prev=>prev+1) 
           },100)
        }
        else if (!isActive && time !== 0) {
            clearInterval(id);
          }
          return () => clearInterval(id);
         
      
    },[isActive, time])
return (
    <div className="wrapper">
            <div className="timer">
                <h1>{time}</h1>
                {/* <h1>{minut}</h1>
                <h1>{second}</h1> */}
            </div>
            <div className="button">
                <button onClick={Start} className="btn btn-primary">Start</button>
                <button onClick={Pause} className="btn btn-warning">Pause</button>
               
            </div>
           
        </div>
)

}
export default Sekund