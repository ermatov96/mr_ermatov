
import './App.css';
import Light from './TraficLight';

function App() {
  
  return (

      <div className="App"> 
       <hr/>
     <Light/>
      </div>
   
  )
}


export default App;
