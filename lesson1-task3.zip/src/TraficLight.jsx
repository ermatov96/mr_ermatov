import './App.css'
import { useState, useEffect } from 'react'

const ligDur = [5000, 2000, 1000];
function Light({intialValue=0}) {
    const [colorIndex, setColorIndex] = useState(intialValue);

    useEffect(() => {
        const timer = setTimeout(() => {
            setColorIndex((colorIndex + 1) % 3);
        }, ligDur[colorIndex])
        return () => {
            clearTimeout(timer);
        };
    })
    return (
        <div className="light">
            <button className={colorIndex===0 && "btn1 btn11" }></button>
            <button  className={colorIndex===1 && "btn2 btn22" }></button>
            <button  className={colorIndex===2 && "btn3 btn33" }></button>
        </div>
    )
}
export default Light