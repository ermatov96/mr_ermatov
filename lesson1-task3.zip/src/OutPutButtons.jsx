import {useState} from 'react'
import './App.css'
import Count from './Counter';
function Out (props){
    const[show, setShow]=useState([])
  
    const outPut=()=>{
        let massive=show;
        massive.push(0)
        setShow([
            ...massive
          ]  )
    }
return(
    <div className="wrapp">
       
        <div className="wrapper2">
        {show.map((index,i)=>(
          
          <h3>{i+1}.  counter{i+1}={props.data}  <Count/> </h3>
           
         ))}
        </div>
        <button onClick={outPut} className="btn btn-success">+Add Counter</button>
      
    </div>
)
}
export default Out