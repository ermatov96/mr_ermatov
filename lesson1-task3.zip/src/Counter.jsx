 import './App.css'
 import {useState} from 'react'

 function Count(props){
const [count, setCounter]=useState(0)
const Add=()=>{
    setCounter(prev=>prev+1);
  

}
const Subs=()=>{
    if(count>0)
    setCounter(prev=>prev-1)
}
    return(
        <div className="wrapper1">
            <h3>{count}</h3>
            <button onClick={Subs} className="btn btn-warning">-</button>
            <button onClick={Add} className="btn btn-primary">+</button>
        </div>
    )
}
export default Count